package keltis.mone.player;

/**
 * <pre>
 * The Player: 
 * The number of players is between 2-4 in each round. 
 * Each player has a name that can be set by the player at the beginning of the game 
 * and a score by which the winner of the game round is determined. 
 * 
 * An internal score of the highest game score ever achieved can be stored in a database.(later possibly)
 * 
 * No constructor, as name and score are set from outside when the game starts. 
 * No Equals, because the name is not compared and the score is only "sorted"... 
 * (Equals as a fallback if querying the PlayerField is not possible via the object itself)
 * No toString
 * @author even0
 * </pre>
 */
public class Player {

	/** Player Score */
	private int score;

	/** Player Name */
	private String nameString;

	public Player(String name) {
		this.nameString = name;
	}

	/**
	 * @return the score from the Player
	 */
	public int getScore() {
		return score;
	}

	/**
	 * @return the nameString of the Player
	 */
	public String getNameString() {
		return nameString;
	}

	/**
	 * @param score the score to set (each Round, start at 0)
	 */
	public void setScore(int score) {
		this.score = score;
	}

	/**
	 * @param nameString the nameString to set from Player to begin of each Round)
	 */
	public void setNameString(String nameString) {
		this.nameString = nameString;
	}
}
