package keltis.mone.player;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import keltis.mone.playstone.PlayStone;

/**
 * <pre>
 * The player field: a new field is set up for each player at the beginning of each game. 
 * The players should place their stones in this field. 
 * When a stone is discarded, points are added to the player's score accordingly. 
 * 
 * The player field has one player and a number of fields in which the stones can be placed. 
 * (1 field per stone -> 5 colors with 11 stones each = 55 fields per player.)
 * @author even0
 * </pre>
 */

public class PlayerFieldFx extends Pane {

	/** Player assigned to the Field */
	private Player player;

	/** Buttons as Play field Placeholder */
	private Label[] fieldLabel = new Label[55];

	private boolean[] labeld = new boolean[55];

	private GridPane playerFieldPane = new GridPane();

	/**
	 * in this list, the stones that the player has collected are listed for later
	 * counting. One List for each Color
	 */
	public List<PlayStone> playerStoneListRed = new ArrayList<>();

	/**
	 * in this list, the stones that the player has collected are listed for later
	 * counting. One List for each Color
	 */
	public List<PlayStone> playerStoneListBlue = new ArrayList<>();

	/**
	 * in this list, the stones that the player has collected are listed for later
	 * counting. One List for each Color
	 */
	public List<PlayStone> playerStoneListGreen = new ArrayList<>();

	/**
	 * in this list, the stones that the player has collected are listed for later
	 * counting. One List for each Color
	 */
	public List<PlayStone> playerStoneListYellow = new ArrayList<>();

	/**
	 * in this list, the stones that the player has collected are listed for later
	 * counting. One List for each Color
	 */
	public List<PlayStone> playerStoneListBrown = new ArrayList<>();

	/**
	 * <pre>
	 * Every time a field is "created" at the beginning of a game, 
	 * a player must be assigned to the field, hence the construct with the player attribute. 
	 * The number of fields is always the same for each field.
	 * @param player
	 * </pre>
	 */
	public PlayerFieldFx(Player player) {
		this.player = player;

//		setLayout(new GridLayout(11,5,2,2));
		buildPlayerField();
		this.getChildren().add(playerFieldPane);
	}

	/** build the Labels for the Player field */
	private void buildPlayerField() {
		for (int i = 0; i < fieldLabel.length; i++) {
			fieldLabel[i] = new Label("");
			fieldLabel[i].setStyle("-fx-background-image: url('resources/Stone.png');" + "-fx-background-size: cover;");
			fieldLabel[i].setPrefSize(48, 25);
			labeld[i] = false;
		}

		int index = 0;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 11; j++) {
				playerFieldPane.add(fieldLabel[index], i, j);
				index++;
			}
		}

	}

	/**
	 * @return the player assigned to the Field
	 */
	public Player getPlayer() {
		return player;
	}

	/**
	 * @return the playerStoneList
	 */
	public List<PlayStone> getPlayerStoneListRed() {
		return playerStoneListRed;
	}

	/**
	 * @param playerStoneList the playerStoneList to set
	 */
	public void setPlayerStoneListRed(List<PlayStone> playerStoneList) {
		this.playerStoneListRed = playerStoneList;
	}

	/**
	 * @return the playerStoneListBlue
	 */
	public List<PlayStone> getPlayerStoneListBlue() {
		return playerStoneListBlue;
	}

	/**
	 * @return the playerStoneListGreen
	 */
	public List<PlayStone> getPlayerStoneListGreen() {
		return playerStoneListGreen;
	}

	/**
	 * @return the playerStoneListYellow
	 */
	public List<PlayStone> getPlayerStoneListYellow() {
		return playerStoneListYellow;
	}

	/**
	 * @return the playerStoneListBrown
	 */
	public List<PlayStone> getPlayerStoneListBrown() {
		return playerStoneListBrown;
	}

	/**
	 * @return the playerFieldPane
	 */
	public GridPane getPlayerFieldPane() {
		return playerFieldPane;
	}

	/**
	 * @return the fieldLabel
	 */
	public Label[] getFieldLabel() {
		return fieldLabel;
	}

	/**
	 * @return the labeld
	 */
	public boolean[] getLabeld() {
		return labeld;
	}

	/**
	 * @param labeld the labeld to set
	 */
	public void setLabeld(boolean[] labeld) {
		this.labeld = labeld;
	}

}
