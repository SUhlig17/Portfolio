package keltis.mone.gameboard;

import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

/**
 * Base Game Board for the Game
 * 
 * @author even0
 *
 */
public class GameBoardFx extends Pane {

	private Pane centerGameBoardPane = new Pane();

	private Button turnEndButton = new Button("end Turn");

	/**
	 * create the GameBoard in the Center
	 */
	public GameBoardFx() {
		centerGameBoardPane.setPrefSize(600, 280);
		centerGameBoardPane.getChildren().add(turnEndButton);
		centerGameBoardPane
				.setStyle("-fx-background-image:url('resources/HolzBrett.jpg');" + "-fx-background-size: cover;");
		this.getChildren().add(centerGameBoardPane);
	}

	/**
	 * @return the turnEndButton
	 */
	public Button getTurnEndButton() {
		return turnEndButton;
	}
}
