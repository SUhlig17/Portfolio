package keltis.mone.manager;

import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import keltis.mone.gameboard.GameBoardFx;
import keltis.mone.player.PlayerFieldFx;
import keltis.mone.playstone.PlayStone;
import keltis.mone.playstone.PlayStoneColor;
import keltis.mone.playstone.PlayStoneSymbol;

/**
 * <pre>
 * The GameManager: is responsible for the execution of the game mechanics. 
 * Executable game mechanics are: revealing a stone, 
 * moving a stone (moving it from one list to another) 
 * -> does not have to be the same stone as the one that was revealed. 
 * end turn.
 * @author even0
 * </pre>
 */
public class GameManager {

	/**
	 * List of all PlayStones from PlaySToneManager
	 */
	private List<PlayStone> allPlayStones;

	private boolean turnEnd = false;

	private RulesManager ruler = new RulesManager();

	private Label[] fieldLabels;

	private boolean[] labeld;

	public GameManager() {
		System.out.println("GameManager +++++++++++++++++++++++++++++++++++++++++++++");
	}

	/** set all Playstones Takeable false */
	public boolean takeable(List<PlayStone> allPlayStones) {
		for (PlayStone playStone : allPlayStones) {
			playStone.setTakeable(false);
		}
		return false;
	}

	/**
	 * TODO reveals a token on the GameBoard. Returns an object? which can then be
	 * moved out of the list.
	 */
	public void revealingPlayStone(PlayStone playStone) {
		if (playStone.isRevealed() == false) {
			playStone.setRevealed(true);
		} else {
			System.err.println("The function should not be called at all. The test takes place in the play method");
		}
	}

	/**
	 * Moves a PlayStone from the main list on the GameBoard to the player's list
	 * and displays it where it can later be counted Checks if move can be executed
	 * or not
	 */
	public void movingGameStone(PlayerFieldFx playerField, PlayStone gameStone) {
		if (allPlayStones.contains(gameStone) && gameStone.isTakeable() == true) {
			PlayStoneColor playStoneColor = gameStone.getStoneColor();
			switch (playStoneColor) {
			case RED: {
				List<PlayStone> playerFieldList = playerField.getPlayerStoneListRed();
				if (ruler.isCompliant(playerFieldList, gameStone)) {
					playerFieldList.add(gameStone);
					allPlayStones.remove(gameStone);
//					System.out.println("Red List: " + playerField.getPlayerStoneListRed());
					ProcressManager.getInstance().setCompliant(true);

					fieldLabels = playerField.getFieldLabel();
					labeld = playerField.getLabeld();
					for (int i = 0; i < 11; i++) {
						if (labeld[i] == false) {
							if (gameStone.getStoneSymbol() != null) {
								Image bild = new Image(gameStone.getStoneSymbol().getSymbolImageString());
								ImageView anzeige = new ImageView(bild);
								anzeige.setFitWidth(20);
								anzeige.setPreserveRatio(true);
								fieldLabels[i].setGraphic(anzeige);
							}
							fieldLabels[i].setAlignment(Pos.CENTER);
							fieldLabels[i]
									.setStyle("-fx-background-image: url('" + gameStone.getStoneColor().getImageString()
											+ "') ;" + "-fx-background-size: cover;");
							fieldLabels[i].setText(gameStone.getStoneNumber() + "");
							labeld[i] = true;
							break;
						}
					}
					if (gameStone.getStoneSymbol() != PlayStoneSymbol.GOLDEN_CLOVER1
							|| gameStone.getStoneSymbol() != PlayStoneSymbol.GOLDEN_CLOVER2) {
						endTurn();
					}
				} else {
					ProcressManager.getInstance().setCompliant(false);
					endTurn();
					System.err.println("move not possible");
				}
				break;
			}
			case GREEN: {
				List<PlayStone> playerFieldList = playerField.getPlayerStoneListGreen();
				if (ruler.isCompliant(playerFieldList, gameStone)) {
					playerFieldList.add(gameStone);
					allPlayStones.remove(gameStone);
//					System.out.println("Green List: " + playerField.getPlayerStoneListGreen());
					ProcressManager.getInstance().setCompliant(true);
					fieldLabels = playerField.getFieldLabel();
					labeld = playerField.getLabeld();
					for (int i = 11; i < 22; i++) {
						if (labeld[i] == false) {
							if (gameStone.getStoneSymbol() != null) {
								Image bild = new Image(gameStone.getStoneSymbol().getSymbolImageString());
								ImageView anzeige = new ImageView(bild);
								anzeige.setFitWidth(20);
								anzeige.setPreserveRatio(true);
								fieldLabels[i].setGraphic(anzeige);
							}
							fieldLabels[i].setAlignment(Pos.CENTER);
							fieldLabels[i]
									.setStyle("-fx-background-image: url('" + gameStone.getStoneColor().getImageString()
											+ "') ;" + "-fx-background-size: cover;");
							fieldLabels[i].setText(gameStone.getStoneNumber() + "");
							labeld[i] = true;
							break;
						}

					}

					endTurn();

				} else {
					ProcressManager.getInstance().setCompliant(false);
					endTurn();
					System.err.println("move not possible");
				}
				break;
			}
			case BLUE: {
				List<PlayStone> playerFieldList = playerField.getPlayerStoneListBlue();
				if (ruler.isCompliant(playerFieldList, gameStone)) {
					playerFieldList.add(gameStone);
					allPlayStones.remove(gameStone);
//					System.out.println("Blue List: " + playerField.getPlayerStoneListBlue());
					ProcressManager.getInstance().setCompliant(true);
					fieldLabels = playerField.getFieldLabel();
					labeld = playerField.getLabeld();
					for (int i = 22; i < 33; i++) {
						if (labeld[i] == false) {
							if (gameStone.getStoneSymbol() != null) {
								Image bild = new Image(gameStone.getStoneSymbol().getSymbolImageString());
								ImageView anzeige = new ImageView(bild);
								anzeige.setFitWidth(20);
								anzeige.setPreserveRatio(true);
								fieldLabels[i].setGraphic(anzeige);
							}
							fieldLabels[i].setAlignment(Pos.CENTER);
							fieldLabels[i]
									.setStyle("-fx-background-image: url('" + gameStone.getStoneColor().getImageString()
											+ "') ;" + "-fx-background-size: cover;");
							fieldLabels[i].setText(gameStone.getStoneNumber() + "");
							labeld[i] = true;
							break;
						}

					}

					endTurn();

				} else {
					ProcressManager.getInstance().setCompliant(false);
					endTurn();
					System.err.println("move not possible");
				}
				break;
			}
			case YELLOW: {
				List<PlayStone> playerFieldList = playerField.getPlayerStoneListYellow();
				if (ruler.isCompliant(playerFieldList, gameStone)) {
					playerFieldList.add(gameStone);
					allPlayStones.remove(gameStone);
//					System.out.println("Yellow List: " + playerField.getPlayerStoneListYellow());
					ProcressManager.getInstance().setCompliant(true);
					fieldLabels = playerField.getFieldLabel();
					labeld = playerField.getLabeld();
					for (int i = 33; i < 44; i++) {
						if (labeld[i] == false) {
							if (gameStone.getStoneSymbol() != null) {
								Image bild = new Image(gameStone.getStoneSymbol().getSymbolImageString());
								ImageView anzeige = new ImageView(bild);
								anzeige.setFitWidth(20);
								anzeige.setPreserveRatio(true);
								fieldLabels[i].setGraphic(anzeige);
							}
							fieldLabels[i].setAlignment(Pos.CENTER);
							fieldLabels[i]
									.setStyle("-fx-background-image: url('" + gameStone.getStoneColor().getImageString()
											+ "') ;" + "-fx-background-size: cover;");
							fieldLabels[i].setText(gameStone.getStoneNumber() + "");
							labeld[i] = true;
							break;
						}

					}

					endTurn();

				} else {
					ProcressManager.getInstance().setCompliant(false);
					endTurn();
					System.err.println("move not possible");
				}
				break;
			}
			case BROWN: {
				List<PlayStone> playerFieldList = playerField.getPlayerStoneListBrown();
				if (ruler.isCompliant(playerFieldList, gameStone)) {
					playerFieldList.add(gameStone);
					allPlayStones.remove(gameStone);
//					System.out.println("Brown List: " + playerField.getPlayerStoneListBrown());
					ProcressManager.getInstance().setCompliant(true);
					fieldLabels = playerField.getFieldLabel();
					labeld = playerField.getLabeld();
					for (int i = 44; i < 55; i++) {
						if (labeld[i] == false) {
							if (gameStone.getStoneSymbol() != null) {
								Image bild = new Image(gameStone.getStoneSymbol().getSymbolImageString());
								ImageView anzeige = new ImageView(bild);
								anzeige.setFitWidth(20);
								anzeige.setPreserveRatio(true);
								fieldLabels[i].setGraphic(anzeige);
							}
							fieldLabels[i].setAlignment(Pos.CENTER);
							fieldLabels[i]
									.setStyle("-fx-background-image: url('" + gameStone.getStoneColor().getImageString()
											+ "') ;" + "-fx-background-size: cover;");
							fieldLabels[i].setText(gameStone.getStoneNumber() + "");
							labeld[i] = true;
							break;
						}
					}

					endTurn();

				} else {
					ProcressManager.getInstance().setCompliant(false);
					endTurn();
					System.err.println("move not possible");
				}
				break;
			}
			default:
				throw new IllegalArgumentException("Unexpected value: " + playStoneColor);
			}
		} else {
			throw new IllegalArgumentException("Unexpected value: " + gameStone);
		}
	}

	/** the player can end the turn if he won`t take the Stone */
	public void playerEndTurn(GameBoardFx gameBoardFx) {
		gameBoardFx.getTurnEndButton().setOnMouseClicked(event -> {
			if (ProcressManager.getInstance().isMoveMade() == true) {
				endTurn();
			}
		});
	}

	/**
	 * returns that the move has ended (boolean true)
	 */
	public boolean endTurn() {
		for (PlayStone playStone : allPlayStones) {
			playStone.setTakeable(true);
		}
		turnEnd = true;
		if (ProcressManager.getInstance().getCounter() == 0) {
			ProcressManager.getInstance().counter();
			System.exit(0);
		}
		System.out.println("Turn End");
		return turnEnd;
	}

	/**
	 * @return the turnEnd
	 */
	public boolean isTurnEnd() {
		return turnEnd;
	}

	/**
	 * @param turnEnd the turnEnd to set
	 */
	public void setTurnEnd(boolean turnEnd) {
		this.turnEnd = turnEnd;
	}

	/**
	 * @param allPlayStones the allPlayStones to set
	 */
	public void setAllPlayStones(List<PlayStone> allPlayStones) {
		this.allPlayStones = allPlayStones;
	}
}
