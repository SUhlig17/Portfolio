package keltis.mone.manager;

import java.util.ArrayList;
import java.util.List;

import keltis.mone.player.PlayerFieldFx;
import keltis.mone.playstone.PlayStone;
import keltis.mone.playstone.PlayStoneColor;
import keltis.mone.playstone.PlayStoneSymbol;

/**
 * <pre>
 * The counter: has access to the players' fields 
 * and counts the points of each field and assigns the score to the player.
 * @author even0
 * </pre>
 */
public class Counter {

	/** helper List summarize all Stones with green Stones to count them */
	private List<PlayStone> greenList = new ArrayList<>();

	/** intern score counter */
	private int score;

	/** method calls the Lists and count them */
	public void counter(PlayerFieldFx playerField) {
		int totalScore = 0;
		totalScore += count(playerField.getPlayerStoneListRed());
		totalScore += count(playerField.getPlayerStoneListGreen());
		totalScore += count(playerField.getPlayerStoneListBlue());
		totalScore += count(playerField.getPlayerStoneListYellow());
		totalScore += count(playerField.getPlayerStoneListBrown());
		totalScore += countGreenList();
		System.out.println("The total of all points of the player is: " + totalScore);
		playerField.getPlayer().setScore(totalScore);
	}

	/**
	 * Method of counting the points for each List
	 * 
	 * @return
	 */
	private int count(List<PlayStone> playerList) {
		score = 0;
		if (playerList.isEmpty()) {
			score += 0;
//			System.out.println("0 Stones = +0 Points");
		}
		if (playerList.size() == 1) {
			score -= 4;
//			System.out.println("1 Stones = -4 Points");
		}
		if (playerList.size() == 2) {
			score -= 3;
//			System.out.println("2 Stones = -3 Points");
		}
		if (playerList.size() == 3) {
			score += 2;
//			System.out.println("3 Stones = +2 Points");
		}
		if (playerList.size() == 4) {
			score += 3;
//			System.out.println("4 Stones = +3 Points");
		}
		if (playerList.size() == 5) {
			score += 6;
//			System.out.println("5 Stones = +6 Points");
		}
		if (playerList.size() >= 6) {
			score += 10;
//			System.out.println("6 ore more Stones = +10 Points");
		}
		for (PlayStone playStone : playerList) {
			if (playStone.getStoneSymbol() == PlayStoneSymbol.ONE_POINT) {
				score += 1;
//				System.out.println("1 Point extra");
			}
			if (playStone.getStoneSymbol() == PlayStoneSymbol.THREE_POINT) {
				score += 3;
//				System.out.println("3 Points extra");
			}
			if (playStone.getStoneSymbol() == PlayStoneSymbol.GREEN_STONE1
					|| playStone.getStoneSymbol() == PlayStoneSymbol.GREEN_STONE2) {
				greenList.add(new PlayStone(PlayStoneColor.RED, 0, null, true));
//				System.out.println("Green Stone addet to List");
			}
		}
//		System.out.println("The score of the List is: " + score);
		return score;
	}

	private int countGreenList() {
		if (greenList.isEmpty()) {
			score -= 4;
//			System.out.println("GreenList 0Stones = -4 Points");
		}
		if (greenList.size() == 1) {
			score -= 3;
//			System.out.println("GreenList 1Stones = -3 Points");
		}
		if (greenList.size() == 2) {
			score += 2;
//			System.out.println("GreenList 2Stones = +2 Points");
		}
		if (greenList.size() == 3) {
			score += 3;
//			System.out.println("GreenList 3Stones = +3 Points");
		}
		if (greenList.size() == 4) {
			score += 6;
//			System.out.println("GreenList 4Stones = +6 Points");
		}
		if (greenList.size() >= 5) {
			score += 10;
//			System.out.println("GreenList 5Stones = +10 Points");
		}
		return score;
	}
}
