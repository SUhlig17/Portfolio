package keltis.mone.manager;

import keltis.mone.player.PlayerFieldFx;
import keltis.mone.playstone.PlayStone;

/**
 * <pre>
 * the ProcessManager: monitors the progress of the game
 * 
 * The course of the game is regulated as follows: 
 * The number of players is determined. 
 * Each player is given a name. 
 * Player 1 starts and draws a stone. 
 * He decides to take the stone and move it to his Field or leave it on the Board. 
 * In both cases, the turn ends and it is the next player's turn.
 * This continues until the last PlayStone on the board has been flipped over 
 * and the player has completed their turn.
 * 
 * Special rule: if the player draws a stone with a golden cloverleaf and places it on his field, 
 * he may make one more move. 
 * However, this only applies as long as he places the stone on his field. 
 * If he leaves it on the board, the player who places the piece on his square during his turn may take the extra turn.
 * 
 * @author even0
 * </pre>
 */
public class ProcressManager {

	private static ProcressManager procressManager;

	/** the currently active Player Index */
	private int activePlayer;

	/** all PlayerFields */
	private PlayerFieldFx[] allPlayerFieldFx;

	private GameManager gameManager;

	/** counter for the Stone covers to end the game if the last one is taken */
	private int counter = 55;

	/** is the turn compliant? */
	private boolean compliant;

	/**
	 * was the turn made? to prevent the player from ending his turn without making
	 * a move
	 */
	private boolean moveMade;

	public static ProcressManager getInstance() {
		if (procressManager == null) {
			procressManager = new ProcressManager();
		}
		return procressManager;
	}

	/** count the uncovered Stones to determine the end of the game */
	public void countCover() {
		counter = getCounter() - 1;
	}

	/** change to the nextPlayer */
	public void playerTurn(PlayStone playStone) {
		gameManager.movingGameStone(allPlayerFieldFx[activePlayer], playStone);

		if (gameManager.isTurnEnd() == true) {
			activePlayer = (activePlayer + 1) % allPlayerFieldFx.length;
			System.out.println("playerTurn: " + activePlayer);
		}
	}

	/** in the End Counts the points of Each player */
	public void counter() {
		Counter counter = new Counter();
		for (int i = 0; i < allPlayerFieldFx.length; i++) {
			counter.counter(getActivePlayer());
		}
	}

	/**
	 * Passes on the check of the move to avoid making a stone not visible that
	 * cannot be taken.
	 */
	public void compliant() {
		setCompliant(true);
	}

	/**
	 * @param allPlayerFieldFx the allPlayerFieldFx to set
	 */
	public void setAllPlayerFieldFx(PlayerFieldFx[] allPlayerFieldFx) {
		this.allPlayerFieldFx = allPlayerFieldFx;
		activePlayer = 0;
	}

	/**
	 * @return the activePlayer
	 */
	public PlayerFieldFx getActivePlayer() {
		return allPlayerFieldFx[activePlayer];
	}

	/**
	 * @param gameManager the gameManager to set
	 */
	public void setGameManager(GameManager gameManager) {
		this.gameManager = gameManager;
	}

	/**
	 * @return the counter
	 */
	public int getCounter() {
		return counter;
	}

	/**
	 * @return the compliant
	 */
	public boolean isCompliant() {
		return compliant;
	}

	/**
	 * @param compliant the compliant to set
	 */
	public void setCompliant(boolean compliant) {
		this.compliant = compliant;
	}

	/**
	 * @return the moveMade
	 */
	public boolean isMoveMade() {
		return moveMade;
	}

	/**
	 * @param moveMade the moveMade to set
	 */
	public void setMoveMade(boolean moveMade) {
		this.moveMade = moveMade;
	}

}
