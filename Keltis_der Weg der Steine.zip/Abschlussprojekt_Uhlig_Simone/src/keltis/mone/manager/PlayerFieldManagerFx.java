package keltis.mone.manager;

import javafx.geometry.Pos;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import keltis.mone.gameboard.GameBoardFx;
import keltis.mone.player.Player;
import keltis.mone.player.PlayerFieldFx;

/**
 * <pre>
 * The PlayerFiledManger: builds the playing field based on the number of players who are logged in. (min 2 and max 4)
 * @author even0
 * </pre>
 */

public class PlayerFieldManagerFx extends BorderPane {

	/** Player Field Player 1 one bottom */
	private PlayerFieldFx belowPlayerPane = new PlayerFieldFx(new Player("Player 1"));

	/** Player Field Player 2 one top */
	private PlayerFieldFx topPlayerPane = new PlayerFieldFx(new Player("Player2"));

	/** Player Field Player 3 one the left */
	private PlayerFieldFx leftPlayerPane = new PlayerFieldFx(new Player("Player3"));

	/** Player Field Player 4 one the right */
	private PlayerFieldFx rightPlayerPane = new PlayerFieldFx(new Player("Player4"));

	/** TODO GmaeBoard from the Center */
	private GameBoardFx gameBoardJPane = new GameBoardFx();

	private PlayerFieldFx[] playerFields;

	/** Constructor to call in the frontend class */
	public PlayerFieldManagerFx(int numberOfPlayer) {
		buildPlayerField(numberOfPlayer);
	}

	/**
	 * Build the Panels based on the number of players
	 */
	private PlayerFieldFx[] buildPlayerField(int numberOfPlayer) {
//System.out.println("hello");

		HBox belowPanel = new HBox();
		HBox topPanel = new HBox();
		VBox leftPanel = new VBox();
		VBox rightPanel = new VBox();

//		belowPanel.setStyle("-fx-background-color: #9575CD");
//		topPanel.setStyle("-fx-background-color: #EC407A");
//		leftPanel.setStyle("-fx-background-color: #26C6DA");
//		rightPanel.setStyle("-fx-background-color: #AED581");
//		
//		belowPlayerPane.setStyle("-fx-background-color: #AD1457");
//		topPlayerPane.setStyle("-fx-background-color: #64B5F6");
//		leftPlayerPane.setStyle("-fx-background-color: #0277BD");
//		rightPlayerPane.setStyle("-fx-background-color: #558B2F");	

		belowPanel.getChildren().add(belowPlayerPane);
		topPanel.getChildren().add(topPlayerPane);
		leftPanel.getChildren().add(leftPlayerPane);
		rightPanel.getChildren().add(rightPlayerPane);

		belowPanel.setAlignment(Pos.CENTER);
		topPanel.setAlignment(Pos.CENTER);
		leftPanel.setAlignment(Pos.CENTER);
		rightPanel.setAlignment(Pos.CENTER);

		setBottom(belowPanel);
		setTop(topPanel);
		setLeft(leftPanel);
		setRight(rightPanel);

		setCenter(gameBoardJPane);

		switch (numberOfPlayer) {
		case 2: {
			leftPlayerPane.setVisible(false);
			rightPlayerPane.setVisible(false);
			playerFields = new PlayerFieldFx[2];
			playerFields[0] = belowPlayerPane;
			playerFields[1] = topPlayerPane;
			return playerFields;
//			break;
		}
		case 3: {
			rightPlayerPane.setVisible(false);
			playerFields = new PlayerFieldFx[3];
			playerFields[0] = belowPlayerPane;
			playerFields[1] = topPlayerPane;
			playerFields[2] = leftPlayerPane;
			return playerFields;
//			break;
		}
		case 4: {
			playerFields = new PlayerFieldFx[4];
			playerFields[0] = belowPlayerPane;
			playerFields[1] = topPlayerPane;
			playerFields[2] = leftPlayerPane;
			playerFields[3] = rightPlayerPane;
			return playerFields;
//			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + numberOfPlayer);
		}
	}

	/**
	 * @return the gameBoardJPane
	 */
	public GameBoardFx getGameBoardJPane() {
		return gameBoardJPane;
	}

	/**
	 * @return the playerFields
	 */
	public PlayerFieldFx[] getPlayerFields() {
		return playerFields;
	}
}
