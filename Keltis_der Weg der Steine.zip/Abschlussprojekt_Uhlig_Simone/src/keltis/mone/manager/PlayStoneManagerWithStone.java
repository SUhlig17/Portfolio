package keltis.mone.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import javafx.scene.layout.Pane;
import keltis.mone.playstone.PlayStone;
import keltis.mone.playstone.PlayStoneColor;
import keltis.mone.playstone.PlayStoneObject;
import keltis.mone.playstone.PlayStoneSymbol;
import keltis.mone.playstone.Positions;

/**
 * generates a list (has the better methods to work with for the Game)
 * containing 55 stones (5 colors with 11 stones each)
 * 
 * Each stone of a color has the possibility to carry a symbol next to the
 * number.
 * 
 * there are 4 different symbols, 2 of which can appear twice in each color. the
 * other 2 per color only once each.
 * 
 * Each stone can have a maximum of 1 symbol.
 * 
 * @author even0
 *
 */
public class PlayStoneManagerWithStone {

	/** 5 Lists for each Color to set the symbols */
	private List<PlayStone> redList = new ArrayList<>();
	private List<PlayStone> yellowList = new ArrayList<>();
	private List<PlayStone> greenList = new ArrayList<>();
	private List<PlayStone> blueList = new ArrayList<>();
	private List<PlayStone> brownList = new ArrayList<>();

	/** the final List with all Stones */
	private List<PlayStone> allPlayStones = new ArrayList<>();

	private GameManager gameManager;

	/**
	 * @param gameManager
	 */
	public PlayStoneManagerWithStone(GameManager gameManager) {
		this.gameManager = gameManager;
	}

	/**
	 * calls the genaratePlayStones and initialize them
	 */
	public void generatedList() {
		generatePlayStones(redList, PlayStoneColor.RED);
		generatePlayStones(yellowList, PlayStoneColor.YELLOW);
		generatePlayStones(greenList, PlayStoneColor.GREEN);
		generatePlayStones(blueList, PlayStoneColor.BLUE);
		generatePlayStones(brownList, PlayStoneColor.BROWN);
	}

	/**
	 * input the list and the Color from generatedList initialize first Loop adds
	 * the Stones in the List second Loop initialized random the symbols for the
	 * Stones
	 * 
	 * @param list
	 * @param color
	 */
	private void generatePlayStones(List<PlayStone> list, PlayStoneColor color) {

		for (int i = 0; i < 11; i++) {
			PlayStone stone = new PlayStone(color, i, null, false);
			list.add(stone);
			allPlayStones.add(stone);
		}

		Random diceRandom = new Random();
		int stoneIndex = diceRandom.nextInt(list.size());

		for (PlayStoneSymbol symbol : PlayStoneSymbol.values()) {
			list.get(stoneIndex).setStoneSymbol(symbol);
			list.remove(stoneIndex);
			stoneIndex = diceRandom.nextInt(list.size());
		}
		gameManager.setAllPlayStones(allPlayStones);
	}

	/**
	 * generates the stone objects in random order on the board
	 * 
	 * @param board
	 */
	public void createStoneObject(Pane board) {
		Positions positions = new Positions();
		Collections.shuffle(allPlayStones);
		for (int i = 0; i < positions.getPositions().length; i++) {
			PlayStoneObject stoneObject = new PlayStoneObject(allPlayStones.get(i), i, gameManager, this);
			stoneObject.showStoneObjects(board);
		}
	}

	/**
	 * @return the allPlayStones
	 */
	public List<PlayStone> getAllPlayStones() {
//		allPlayStones.forEach(stone -> System.out.println(stone));
		return allPlayStones;
	}

}
