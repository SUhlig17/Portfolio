package keltis.mone.manager;

import java.util.List;

import keltis.mone.playstone.PlayStone;

/**
 * checks whether a move is possible or not. if yes returns a true if not false,
 * 
 * @author even0
 *
 */
public class RulesManager {

	private int playerFiledListLength;

	/** examination */
	public boolean isCompliant(List<PlayStone> playerFieldList, PlayStone playStone) {

		playerFiledListLength = playerFieldList.size();
		switch (playerFiledListLength) {
		case 0:
//			System.out.println("this is the 1 Stone on the List");
			return true;
		case 1:
//			System.out.println("this is the 2 Stone on the List");
			return true;
		case 2:
			if (playerFieldList.get(0).getStoneNumber() < playerFieldList.get(1).getStoneNumber()
					&& playerFieldList.get(1).getStoneNumber() < playStone.getStoneNumber()) {
//				System.out.println("this is the 3 on the List and is < than the 2");
				return true;
			} else if (playerFieldList.get(0).getStoneNumber() > playerFieldList.get(1).getStoneNumber()
					&& playerFieldList.get(1).getStoneNumber() > playStone.getStoneNumber()) {
//					System.out.println("this is the 3 on the List and is > than the 2");
				return true;
			}
		case 3:
		case 4:
		case 5:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
			if (playerFieldList.get(0).getStoneNumber() < playerFieldList.get(1).getStoneNumber()
					&& playerFieldList.get(playerFieldList.size() - 1).getStoneNumber() < playStone.getStoneNumber()) {
//				System.out.println("this is the ... on the List and is < than the ...");
				return true;
			} else if (playerFieldList.get(0).getStoneNumber() > playerFieldList.get(1).getStoneNumber()
					&& playerFieldList.get(playerFieldList.size() - 1).getStoneNumber() > playStone.getStoneNumber()) {
//				System.out.println("this is the ... on the List and is > than the ...");
				return true;
			}
		default:
			return false;
		}
	}

//	/** examination */
//	public boolean isCompliant(List<PlayStone> playerFieldList, PlayStone playStone) {
//		if (playerFieldList.isEmpty()) {
//			System.out.println("this is the 1 Stone on the List");
//			return true;
//		} else if (playerFieldList.contains(playStone)) {
//			System.err.println("The Stone is dubbled");
//			return false;
//		} else if (playerFieldList.size() == 1) {
//			System.out.println("this is the 2 Stone on the List");
//			return true;
//		} else if (playerFieldList.get(0).getStoneNumber() < playerFieldList.get(1).getStoneNumber()
//				&& playerFieldList.get(1).getStoneNumber() < playStone.getStoneNumber()) {
//			System.out.println("this is the 3 on the List and is < than the 2");
//			return true;
//		} else if (playerFieldList.get(0).getStoneNumber() > playerFieldList.get(1).getStoneNumber()
//				&& playerFieldList.get(1).getStoneNumber() > playStone.getStoneNumber()) {
//			System.out.println("this is the 3 on the List and is > than the 2");
//			return true;
//		} else if (playerFieldList.get(0).getStoneNumber() < playerFieldList.get(1).getStoneNumber()
//				&& playerFieldList.get(playerFieldList.size() - 1).getStoneNumber() < playStone.getStoneNumber()) {
//			System.out.println("this is the ... on the List and is < than the ...");
//			return true;
//		} else if (playerFieldList.get(0).getStoneNumber() > playerFieldList.get(1).getStoneNumber()
//				&& playerFieldList.get(playerFieldList.size() - 1).getStoneNumber() > playStone.getStoneNumber()) {
//			System.out.println("this is the ... on the List and is > than the ...");
//			return true;
//		} else {
//			return false;
//		}
//	}

}
