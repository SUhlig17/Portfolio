package keltis.mone.manager;

import javafx.scene.layout.Pane;

/**
 * <pre>
 * the ProcessManager: monitors the progress of the game
 * 
 * The course of the game is regulated as follows: 
 * The number of players is determined. 
 * Each player is given a name. 
 * Player 1 starts and draws a stone. 
 * He decides to take the stone and move it to his Field or leave it on the Board. 
 * In both cases, the turn ends and it is the next player's turn.
 * This continues until the last PlayStone on the board has been flipped over 
 * and the player has completed their turn.
 * 
 * Special rule: if the player draws a stone with a golden cloverleaf and places it on his field, 
 * he may make one more move. 
 * However, this only applies as long as he places the stone on his field. 
 * If he leaves it on the board, the player who places the piece on his square during his turn may take the extra turn.
 * 
 * @author even0
 * </pre>
 */
public class GameStartManager extends Pane {

	/** starts the game and called all necessary Manager */
	public void startGame(int numberOfPlayer) {
		GameManager gameManager = new GameManager();

		PlayStoneManagerWithStone generatedStoneManager = new PlayStoneManagerWithStone(gameManager);
		generatedStoneManager.generatedList();

		PlayerFieldManagerFx playerFieldManagerFx = new PlayerFieldManagerFx(numberOfPlayer);
		this.getChildren().add(playerFieldManagerFx);
//		TODO Pass name from frontend to object		
//		for(int i = 0; i < numberOfPlayer; i++) {
//			PlayerField player = new PlayerField(new Player("player1"/** set name from Start*/));
//			System.out.println("player " + i + "is created");
//		}		
		generatedStoneManager.createStoneObject(playerFieldManagerFx.getGameBoardJPane());
		ProcressManager procressManager = ProcressManager.getInstance();
		procressManager.setGameManager(gameManager);
		procressManager.setAllPlayerFieldFx(playerFieldManagerFx.getPlayerFields());
		gameManager.playerEndTurn(playerFieldManagerFx.getGameBoardJPane());
	}
}
