package keltis.mone.playstone;

/**
 * <pre>
 * Each stone of a color has the possibility to carry a symbol next to the number. 
 * 
 * there are 4 different symbols, 
 * 2 of which can appear twice in each color. 
 * the other 2 per color only once each. 
 * 
 * Each stone can have a maximum of 1 symbol.
 * @author even0
 * </pre>
 */
public enum PlayStoneSymbol {
	ONE_POINT("resources/Point_1.png"), THREE_POINT("resources/Point_3.png"), GOLDEN_CLOVER1("resources/Clover.png"),
	GOLDEN_CLOVER2("resources/Clover.png"), GREEN_STONE1("resources/GreenPoint.png"),
	GREEN_STONE2("resources/GreenPoint.png");

	/** picture String for symbolPicture */
	private String symbolImageString;

	/**
	 * @param symbolImageString
	 */
	private PlayStoneSymbol(String symbolImageString) {
		this.symbolImageString = symbolImageString;
	}

	/**
	 * @return the symbolImageString
	 */
	public String getSymbolImageString() {
		return symbolImageString;
	}

}
