package keltis.mone.playstone;

/**
 * <pre>
 * The PlayStones: are the main components of the game. 
 * There are 55 tiles in total. 
 * 5 colors with 11 stones from 0 to 10. 
 * @author even0
 * </pre>
 */
public enum PlayStoneColor {
	RED("resources/redStone.png"), YELLOW("resources/yellowStone.png"), GREEN("resources/greenStone.png"),
	BLUE("resources/blueStone.png"), BROWN("resources/brownStone.png");

	/** picture String for coloredStonePicture */
	private String imageString;

	/**
	 * @param imageString
	 */
	private PlayStoneColor(String imageString) {
		this.imageString = imageString;
	}

	/**
	 * @return the imageString
	 */
	public String getImageString() {
		return imageString;
	}
}
