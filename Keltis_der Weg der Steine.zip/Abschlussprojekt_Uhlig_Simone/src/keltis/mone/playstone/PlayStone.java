package keltis.mone.playstone;

/**
 * <pre>
 * The PlayStones: are the main components of the game. 
 * There are 55 tiles in total. 
 * 5 colors with 11 stones from 0 to 10. 
 * 
 * Each stone of a color has the possibility to carry a symbol next to the number. 
 * 
 * there are 4 different symbols, 
 * 2 of which can appear twice in each color. 
 * the other 2 per color only once each. 
 * 
 * Each stone can have a maximum of 1 symbol.
 * 
 * The symbols are represented with integers because strings would be too complicated to compare and process, 
 * while numbers can be easily and relatively uncomplicatedly worked on later when it comes to the calculation.
 * @author even0
 * </pre>
 */
public class PlayStone {

	/** The Color of the Stone */
	private PlayStoneColor stoneColor;

	/** The Number of the Stone needed to "sort" the stones */
	private int stoneNumber;

	/** A Integer that says what kind of symbol are imprinted on the Stone */
	private PlayStoneSymbol stoneSymbol;

	/** has the stone been uncovered yet? (yes true/ no false) false when created */
	private boolean revealed = false;

	private boolean takeable = true;

	/**
	 * @param stoneColor
	 * @param stoneNumber
	 * @param stoneSymbol
	 */
	public PlayStone(PlayStoneColor stoneColor, int stoneNumber, PlayStoneSymbol stoneSymbol, boolean revealed) {
		super();
		this.stoneColor = stoneColor;
		this.stoneNumber = stoneNumber;
		this.stoneSymbol = stoneSymbol;
		this.revealed = revealed;
	}

	/**
	 * @return the revealed
	 */
	public boolean isRevealed() {
		return revealed;
	}

	/**
	 * @return the stoneColor
	 */
	public PlayStoneColor getStoneColor() {
		return stoneColor;
	}

	/**
	 * @return the stoneNumber
	 */
	public int getStoneNumber() {
		return stoneNumber;
	}

	/**
	 * @return the stoneSymbol
	 */
	public PlayStoneSymbol getStoneSymbol() {
		return stoneSymbol;
	}

	/**
	 * @return the takeable
	 */
	public boolean isTakeable() {
		return takeable;
	}

	/**
	 * @param takeable the takeable to set
	 */
	public void setTakeable(boolean takeable) {
		this.takeable = takeable;
	}

	/**
	 * @param revealed the revealed to set
	 */
	public void setRevealed(boolean revealed) {
		this.revealed = revealed;
	}

	/**
	 * @param stoneColor the stoneColor to set
	 */
	public void setStoneColor(PlayStoneColor stoneColor) {
		this.stoneColor = stoneColor;
	}

	/**
	 * @param stoneNumber the stoneNumber to set
	 */
	public void setStoneNumber(int stoneNumber) {
		this.stoneNumber = stoneNumber;
	}

	/**
	 * @param stoneSymbol the stoneSymbol to set
	 */
	public void setStoneSymbol(PlayStoneSymbol stoneSymbol) {
		this.stoneSymbol = stoneSymbol;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((stoneColor == null) ? 0 : stoneColor.hashCode());
		result = prime * result + stoneNumber;
		return result;
	}

	/**
	 * compares the color and number of the stone to allow transfer from one list to
	 * another
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		PlayStone other = (PlayStone) obj;
		if (stoneColor != other.stoneColor) {
			return false;
		}
		if (stoneNumber != other.stoneNumber) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return stoneColor + " " + stoneNumber + " " + stoneSymbol + " " + revealed;
	}

	public String toLabelString() {
		return stoneNumber + " " + stoneSymbol;
	}

}
