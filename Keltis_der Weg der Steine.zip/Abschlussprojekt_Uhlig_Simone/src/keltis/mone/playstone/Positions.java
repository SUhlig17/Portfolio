package keltis.mone.playstone;

/**
 * <pre>
 * Determines the position of the stone images within the given label
 * 
 * TODO possibly pack in a loop with random positioning
 * or arrange stones beautifully by hand
 * return position
 * @author even0
 * </pre>
 *
 */
public class Positions {
	private Position[] positions = new Position[55];

	public Positions() {
		positions[0] = new Position(30, 10);
		positions[1] = new Position(80, 10);
		positions[2] = new Position(130, 10);
		positions[3] = new Position(180, 10);
		positions[4] = new Position(230, 10);
		positions[5] = new Position(280, 10);
		positions[6] = new Position(330, 10);
		positions[7] = new Position(380, 10);
		positions[8] = new Position(430, 10);
		positions[9] = new Position(480, 10);
		positions[10] = new Position(530, 10);

		positions[11] = new Position(10, 60);
		positions[12] = new Position(60, 60);
		positions[13] = new Position(110, 60);
		positions[14] = new Position(160, 60);
		positions[15] = new Position(210, 60);
		positions[16] = new Position(260, 60);
		positions[17] = new Position(310, 60);
		positions[18] = new Position(360, 60);
		positions[19] = new Position(410, 60);
		positions[20] = new Position(460, 60);
		positions[21] = new Position(510, 60);

		positions[22] = new Position(30, 110);
		positions[23] = new Position(80, 110);
		positions[24] = new Position(130, 110);
		positions[25] = new Position(180, 110);
		positions[26] = new Position(230, 110);
		positions[27] = new Position(280, 110);
		positions[28] = new Position(330, 110);
		positions[29] = new Position(380, 110);
		positions[30] = new Position(430, 110);
		positions[31] = new Position(480, 110);
		positions[32] = new Position(530, 110);

		positions[33] = new Position(10, 160);
		positions[34] = new Position(60, 160);
		positions[35] = new Position(110, 160);
		positions[36] = new Position(160, 160);
		positions[37] = new Position(210, 160);
		positions[38] = new Position(260, 160);
		positions[39] = new Position(310, 160);
		positions[40] = new Position(360, 160);
		positions[41] = new Position(410, 160);
		positions[42] = new Position(460, 160);
		positions[43] = new Position(510, 160);

		positions[44] = new Position(30, 210);
		positions[45] = new Position(80, 210);
		positions[46] = new Position(130, 210);
		positions[47] = new Position(180, 210);
		positions[48] = new Position(230, 210);
		positions[49] = new Position(280, 210);
		positions[50] = new Position(330, 210);
		positions[51] = new Position(380, 210);
		positions[52] = new Position(430, 210);
		positions[53] = new Position(480, 210);
		positions[54] = new Position(530, 210);
	}

	public Position[] getPositions() {
		return positions;
	}
}
