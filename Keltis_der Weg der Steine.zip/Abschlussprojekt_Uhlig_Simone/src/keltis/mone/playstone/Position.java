package keltis.mone.playstone;

/**
 * Determines the position of the stone images within the given label
 * 
 * @author even0
 *
 */
public class Position {

	private int xDirection;
	private int yDirection;

	/**
	 * @param xDirection
	 * @param yDirection
	 */
	public Position(int xDirection, int yDirection) {
		this.xDirection = xDirection;
		this.yDirection = yDirection;
	}

	/**
	 * @return the xDirection
	 */
	public int getxDirection() {
		return xDirection;
	}

	/**
	 * @return the yDirection
	 */
	public int getyDirection() {
		return yDirection;
	}

}
