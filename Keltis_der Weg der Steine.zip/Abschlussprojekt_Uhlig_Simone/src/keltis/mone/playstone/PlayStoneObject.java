package keltis.mone.playstone;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import keltis.mone.manager.GameManager;
import keltis.mone.manager.PlayStoneManagerWithStone;
import keltis.mone.manager.ProcressManager;

/**
 * <pre>
 * PlayStoneObject: Puts together the cover, 
 * the data contained in the stone (color, number, symbol) 
 * and the front end of the PlayStone
 * in one Object
 * @author even0
 * </pre>
 */
public class PlayStoneObject {

	private int positionIndex;
	private Label cover = new Label();
	private Label stoneImage = new Label();
	private PlayStone stone;

	private Positions allPositions = new Positions();

	private GameManager gameManager;
	PlayStoneManagerWithStone playStoneManager;

	private Position[] positions;

	/**
	 * Constructor for PlayStoneObject creation
	 */
	public PlayStoneObject(PlayStone stone, int index, GameManager gameManager,
			PlayStoneManagerWithStone playStoneManagerWithStone) {
		positions = allPositions.getPositions();
		this.gameManager = gameManager;
		this.playStoneManager = playStoneManagerWithStone;
		this.stone = stone;
		positionIndex = index;
		create();
		activateStones();
	}

	/**
	 * add the Stone Objects to the GameBoard
	 * 
	 * @param board
	 */
	public void showStoneObjects(Pane board) {
		board.getChildren().add(stoneImage);
		board.getChildren().add(cover);
	}

	/**
	 * create the StoneObjects
	 */
	public void create() {
		cover.setLayoutX(positions[positionIndex].getxDirection());
		stoneImage.setLayoutX(positions[positionIndex].getxDirection());
		cover.setLayoutY(positions[positionIndex].getyDirection());
		stoneImage.setLayoutY(positions[positionIndex].getyDirection());
		stoneImage.setText(stone.getStoneNumber() + "");
		stoneImage.setFont(new Font(15));
		if (stone.getStoneSymbol() != null) {
			Image bild = new Image(stone.getStoneSymbol().getSymbolImageString());
			ImageView anzeige = new ImageView(bild);
			anzeige.setFitWidth(20);
			anzeige.setPreserveRatio(true);
			stoneImage.setGraphic(anzeige);
		}
		stoneImage.setAlignment(Pos.CENTER);
		stoneImage.setPrefSize(70, 60);
		cover.setPrefSize(70, 60);

		stoneImage.setStyle("-fx-background-image: url('" + stone.getStoneColor().getImageString() + "') ;"
				+ "-fx-background-size: cover;");

		cover.setStyle("-fx-background-image: " + "url('resources/Stone.png')" + ";" + "-fx-background-size: cover;");
	}

	/**
	 * Click to reveal the PlayStone and/or click to take the stone
	 */
	public void activateStones() {

		cover.setOnMouseClicked(click -> {
			if (stone.isTakeable() == true) {
				cover.setVisible(false);
				System.out.println(stone + " letzter aufgedeckter Stein");
				stone.setRevealed(true);
				stone.isRevealed();
				gameManager.takeable(playStoneManager.getAllPlayStones());
				stone.setTakeable(true);

				ProcressManager.getInstance().setMoveMade(true);
				ProcressManager.getInstance().countCover();

			}
		});

		// is Takeable to be sure that only the stone can be taken

		stoneImage.setOnMouseClicked(eve -> {
			if (stone.isTakeable()) {
//				System.out.println("Take: " + stone);
				ProcressManager.getInstance().playerTurn(stone);
				if (ProcressManager.getInstance().isCompliant() == true) {
					stoneImage.setVisible(false);
				}
			}

		});

	}
}
