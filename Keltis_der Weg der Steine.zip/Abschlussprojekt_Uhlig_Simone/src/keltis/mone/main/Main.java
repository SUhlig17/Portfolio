package keltis.mone.main;

import javafx.application.Application;
import keltis.mone.display.MainMenu;

/**
 * <pre>
 * starts the Game
 * 
 * overAll TODO
 * Pass the name from the frontend to the player and playing field so that 
 * 											counters etc have access to it. 
 * Output front end for score and winner. 
 * Let the counter (?) announce winners.
 * EndGame should be displayed.
 * @author even0
 * </pre>
 */
public class Main {

	/**
	 * starts the Application
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		Application.launch(MainMenu.class);

	}

}
