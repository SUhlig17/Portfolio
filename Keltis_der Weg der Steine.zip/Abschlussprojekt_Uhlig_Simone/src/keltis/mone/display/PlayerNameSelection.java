package keltis.mone.display;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * @author even0
 *
 */
public class PlayerNameSelection {
	/** stage for changing Scene */
	private Stage primaryStage;

	/** Scene for changing Scene */
	private Scene keltisPlayerNameStage;

	/** number of player min. Number of 2*/
	private int numberOfPlayer = 2;

	/** constructor for Scene PlayerNameSelection */
	public PlayerNameSelection(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	/** create the LAyout for the Scene based on Number of Player */
	public void createScene(String numberOfPlayer) {
		GridPane gridPane = new GridPane();
		gridPane.setAlignment(Pos.BOTTOM_LEFT);
		gridPane.setPadding(new Insets(25, 10, 25, 10));

		Label player1 = new Label("Player 1");
		Label player2 = new Label("Player 2");
		Label player3 = new Label("Player 3");
		Label player4 = new Label("Player 4");

		TextField playerName1 = new TextField();
		TextField playerName2 = new TextField();
		TextField playerName3 = new TextField();
		TextField playerName4 = new TextField();

		VBox playerNameBox = new VBox(10);

		switch (numberOfPlayer) {
		case " 2 ": {
			playerName3.setVisible(false);
			playerName4.setVisible(false);
			player3.setVisible(false);
			player4.setVisible(false);
			setNumberOfPlayer(2);
			break;
		}
		case " 3 ": {
			playerName4.setVisible(false);
			player4.setVisible(false);
			setNumberOfPlayer(3);
			break;
		}
		case " 4 ": {
			setNumberOfPlayer(4);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + numberOfPlayer);
		}

		Button startButton = new Button("Start Game");
		gridPane.add(startButton, 1, 2);
		startButton.setOnAction(event -> {
			GameBoardDisplayFx gameBoardDisplayFx = new GameBoardDisplayFx(primaryStage);
			gameBoardDisplayFx.createScene(getNumberOfPlayer());
			primaryStage.setScene(gameBoardDisplayFx.getGameBoardDisplayScene());

		});

		playerNameBox.getChildren().addAll(player1, playerName1, player2, playerName2, player3, playerName3, player4,
				playerName4, startButton);
		gridPane.add(playerNameBox, 0, 0, 2, 2);

		keltisPlayerNameStage = new Scene(gridPane, 400, 500);
		keltisPlayerNameStage.getStylesheets()
				.add("https://fonts.googleapis.com/css2?family=Amita:wght@700&display=swap");
		keltisPlayerNameStage.getStylesheets().add("resources/stylesheet.css");

	}

	/**
	 * @return the keltisPlayerNameStage
	 */
	public Scene getKeltisPlayerNameStage() {
		return keltisPlayerNameStage;
	}

	/**
	 * @return the numberOfPlayer
	 */
	public int getNumberOfPlayer() {
		return numberOfPlayer;
	}

	/**
	 * @param numberOfPlayer the numberOfPlayer to set
	 */
	public void setNumberOfPlayer(int numberOfPlayer) {
		this.numberOfPlayer = numberOfPlayer;
	}

}
