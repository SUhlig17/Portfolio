package keltis.mone.display;

import javafx.scene.Scene;
import javafx.stage.Stage;
import keltis.mone.manager.GameStartManager;

/**
 * <pre>
 * The GameBoard Display: connects the Game Board and the PlayerFields with each other
 * @author even0
 * </pre>
 */

public class GameBoardDisplayFx {
	/** stage for changing Scene */
	private Stage primaryStage;

	private Scene gameBoardDisplayScene;

	/**
	 * @param primaryStage
	 */
	public GameBoardDisplayFx(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	/**
	 * create the scene with number of Player
	 * 
	 * @param numberOfPlayer
	 */
	public void createScene(int numberOfPlayer) {
		GameStartManager processManager = new GameStartManager();
		processManager.startGame(numberOfPlayer);

		gameBoardDisplayScene = new Scene(processManager);
		primaryStage.setFullScreen(true);
		gameBoardDisplayScene.getStylesheets()
				.add("https://fonts.googleapis.com/css2?family=Amita:wght@700&display=swap");
		gameBoardDisplayScene.getStylesheets().add("resources/gameBoardDisplay.css");
	}

	/**
	 * @return the gameBoardDisplayScene
	 */
	public Scene getGameBoardDisplayScene() {
		return gameBoardDisplayScene;
	}

}
