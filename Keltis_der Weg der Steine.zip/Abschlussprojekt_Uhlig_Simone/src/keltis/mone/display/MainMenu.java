package keltis.mone.display;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * <pre>
 * The MainMenu: provides the 
 * selection of the number of players, 
 * doesn't go lower then 2 and not higher then 4
 * the GameStartButton and 
 * the Exit Button, 
 * the menu is extended if required
 * @author even0
 * </pre>
 */

public class MainMenu extends Application {

	/**
	 * stage of the Main Menu
	 */
	private Stage primaryStage;

	@Override
	public void start(Stage primaryStage) // throws Exception
	{

		this.primaryStage = primaryStage;
		primaryStage.setTitle("Keltis - Der Weg der Steine");
		GridPane gridPane = new GridPane();

		gridPane.setVgap(5);
		gridPane.setHgap(5);

		gridPane.setAlignment(Pos.BOTTOM_CENTER);
		gridPane.setPadding(new Insets(25, 10, 25, 10));

		// -------------------------------------------------------------------------------Player
		// choose---------------------------
		Label selectPlayerLabel = new Label("Choose the number of players");
		Button lessPlayerButton = new Button(" < ");
		Label numberOfPlayerLabel = new Label(" 2 ");
		Button morePlayerButton = new Button(" > ");

		lessPlayerButton.setScaleX(2);
		lessPlayerButton.setScaleY(1);

		numberOfPlayerLabel.setScaleX(2);
		numberOfPlayerLabel.setScaleY(1.5);

		morePlayerButton.setScaleX(2);
		morePlayerButton.setScaleY(1);

		// -------------------------------------------------------------------------------Player
		// choose action--------------------
		lessPlayerButton.setOnAction(click -> {
			switch (numberOfPlayerLabel.getText()) {
			case " 2 ": {
				numberOfPlayerLabel.setText(" 4 ");
				break;
			}
			case " 3 ": {
				numberOfPlayerLabel.setText(" 2 ");
				break;
			}
			case " 4 ": {
				numberOfPlayerLabel.setText(" 3 ");
				break;
			}
			default:
				throw new IllegalArgumentException("Unexpected value: " + numberOfPlayerLabel);
			}
		});

		morePlayerButton.setOnAction(click -> {
			switch (numberOfPlayerLabel.getText()) {
			case " 2 ": {
				numberOfPlayerLabel.setText(" 3 ");
				break;
			}
			case " 3 ": {
				numberOfPlayerLabel.setText(" 4 ");
				break;
			}
			case " 4 ": {
				numberOfPlayerLabel.setText(" 2 ");
				break;
			}
			default:
				throw new IllegalArgumentException("Unexpected value: " + numberOfPlayerLabel);
			}
		});

		// -------------------------------------------------------------------------------StartGameButton-------------------------
		// By pressing the start button, the number of players from the
		// numberOfPlayerLabel and the names should be
		// transferred to the player field class. and the window switch to the playing
		// field
		Button startButton = new Button("Start");

		startButton.setScaleX(2);
		startButton.setScaleY(1);

		startButton.setOnAction(click -> {
			PlayerNameSelection playerNameSelection = new PlayerNameSelection(primaryStage);
			playerNameSelection.createScene(numberOfPlayerLabel.getText());
			primaryStage.setScene(playerNameSelection.getKeltisPlayerNameStage());
		});

		// -------------------------------------------------------------------------------ExitGameButton--------------------------
		// Exit the game
		Button exitButton = new Button("Exit");

		exitButton.setScaleX(2);
		exitButton.setScaleY(1);

		exitButton.setOnAction(click -> System.exit(0));

		// -------------------------------------------------------------------------------arrangement-----------------------------
		// set the Layout
		HBox playerHBox = new HBox();

		gridPane.add(startButton, 6, 2);
		gridPane.add(exitButton, 6, 5);
		gridPane.add(selectPlayerLabel, 0, 0, 7, 1);

		playerHBox.setPadding(new Insets(25, 12, 15, 12));
		playerHBox.setSpacing(30);
		playerHBox.getChildren().addAll(lessPlayerButton, numberOfPlayerLabel, morePlayerButton);

		gridPane.add(playerHBox, 3, 1, 7, 1);
//		gridPane.setGridLinesVisible(true);
		// -------------------------------------------------------------------------------Scene-----------------------------------
		Scene keltisIntroScene = new Scene(gridPane, 400, 500);
		keltisIntroScene.getStylesheets().add("https://fonts.googleapis.com/css2?family=Amita:wght@700&display=swap");
		keltisIntroScene.getStylesheets().add("resources/stylesheet.css");
		primaryStage.setScene(keltisIntroScene);
		primaryStage.show();
	}

	/** getter for Scene change */
	public Stage getPrimaryStage() {
		return primaryStage;
	}
}
