package tests;

import javafx.application.Application;
import keltis.mone.display.MainMenu;

public class FrontendTest {

	public static void main(String[] args) {
		
//		new Frontend().setVisible(true);
		
		Application.launch(MainMenu.class);
	}
}
