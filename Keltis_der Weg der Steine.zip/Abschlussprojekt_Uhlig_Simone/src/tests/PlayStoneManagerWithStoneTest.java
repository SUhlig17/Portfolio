package tests;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import keltis.mone.manager.PlayStoneManagerWithStone;
import keltis.mone.playstone.PlayStone;
import keltis.mone.playstone.PlayStoneColor;
import keltis.mone.playstone.PlayStoneSymbol;

public class PlayStoneManagerWithStoneTest extends Application {
	@Override
	public void start(Stage primaryStage) {
//		Group mitte = new Group();
////		Image pictureImage = new Image("file:resources/Stone.png");
////		ImageView pictureView = new ImageView(pictureImage);
////		mitte.getChildren().add(pictureView);
//		
//		PlayStone stone = new PlayStone(PlayStoneColor.RED, 5, PlayStoneSymbol.GOLDEN_CLOVER1, false);
//		Label stoneLabel = new Label(stone.toLabelString());
//		stoneLabel.setPrefSize(100, 100);
////		stoneLabel.setStyle("-fx-background-image: url('file:resources/Stone.png')");
//		mitte.getChildren().add(stoneLabel);
//		
//		PlayStoneManagerWithStone playStoneManagerWithStone = new PlayStoneManagerWithStone();
//		playStoneManagerWithStone.generatedList();
//		
//		Scene scene = new Scene(mitte,700,700);
//		scene.getStylesheets().add("file:resources/stone.css");
//		
//		primaryStage.setScene(scene);
//		primaryStage.show();
	}
//	public static void main(String[] args) {
//		
//		
//		launch();
//		
//	}


}
