package tests;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;
import keltis.mone.manager.PlayerFieldManagerFx;
import keltis.mone.manager.GameStartManager;

public class GameBoardFxTest extends Application {

	@Override
	public void start(Stage primaryStage) {
		Group mitte = new Group();

//		PlayerFieldManagerFx playerFieldManagerFx = new PlayerFieldManagerFx(3);
//		playerFieldManagerFx.buildPlayerField(4);

//		BorderPane mitte = playerFieldManagerFx.getBorderPane();

		GameStartManager processManager = new GameStartManager();
		processManager.startGame(4);

		Scene scene = new Scene(mitte, 1080, 830);

//		mitte.getChildren().add(playerFieldManagerFx);
		mitte.getChildren().add(processManager);
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	public static void main(String[] args) {

		launch();

	}

}
