package tests;

public class MainMenuTest {

	public static void main(String[] args) {
		
		
	}

}
